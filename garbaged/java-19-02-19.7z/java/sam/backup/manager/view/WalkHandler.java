package sam.backup.manager.view;

import sam.backup.manager.config.api.Config;
import sam.backup.manager.view.config.ConfigView;

public class WalkHandler {

	public void start(Config config, ConfigView configView) {
		// TODO Auto-generated method stub
		// TODO FIXME
	}

	public void stop() {
		// TODO Auto-generated method stub
		
	}
	
}
