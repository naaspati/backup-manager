package sam.backup.manager.extra;

public enum TreeType {
	BACKUP, LIST
}
