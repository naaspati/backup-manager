package sam.backup.manager.walk;

public enum WalkType {
	SOURCE, BACKUP, LIST, NEW_SOURCE
}
