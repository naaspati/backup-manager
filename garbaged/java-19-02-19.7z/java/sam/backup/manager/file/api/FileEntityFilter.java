package sam.backup.manager.file.api;

import java.util.function.Predicate;

public interface FileEntityFilter extends Predicate<FileEntity> { }
