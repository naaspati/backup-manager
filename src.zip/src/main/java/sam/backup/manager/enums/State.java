package sam.backup.manager.enums;

public enum State {
	RUNNING,
	COMPLETED,
	CANCELLED,
	WALKING,
	QUEUED
	
}
