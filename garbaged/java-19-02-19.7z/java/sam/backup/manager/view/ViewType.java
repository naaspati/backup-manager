package sam.backup.manager.view;

public enum ViewType {
	BACKUP, TRANSFER, LIST

}