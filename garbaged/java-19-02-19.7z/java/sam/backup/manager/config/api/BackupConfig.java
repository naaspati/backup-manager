package sam.backup.manager.config.api;

public interface BackupConfig {
	public boolean checkModified();
	public boolean hardSync() ;
}
