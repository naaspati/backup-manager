package sam.backup.manager.config;

public enum StoringMethod {
	NONE, ZIP;
}
