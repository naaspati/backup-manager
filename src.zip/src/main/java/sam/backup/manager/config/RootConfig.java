package sam.backup.manager.config;

import java.nio.file.Path;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Objects;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.slf4j.LoggerFactory;
import org.slf4j.Logger;

import sam.backup.manager.config.filter.IFilter;
import sam.string.StringUtils;
import sam.weak.LazyAndWeak;

public class RootConfig extends ConfigBase {
	private static final long serialVersionUID = 1L;

	private String backupRoot;
	private Config[] backups;
	private Config[]  lists;
	private Map<String, String> variables;

	private transient Path _backupRoot;
	private transient Config[] _backups;
	private transient Config[] _lists;
	
	RootConfig() {}
	
	public Config findConfig(String name) {
		return find(name, getBackups());
	}
	public Config findList(String name) {
		return find(name, getLists());
	}
	private Config find(String name, Config[] cnf) {
		Objects.requireNonNull(name, "name cannot be null");
		return Arrays.stream(cnf).filter(c -> name.equals(c.getName())).findFirst().orElseThrow(() -> new NoSuchElementException("no config found for name: "+name)); 
	}
	public boolean hasLists() {
		return getLists() != null && getLists().length != 0;
	}
	public boolean hasBackups() {
		return  getBackups() != null && getBackups().length != 0;
	}
	public Config[] getLists() {
		if(_lists != null)
			return _lists;

		return _lists = filterAndPrepare(lists); 
	}
	private Config[] filterAndPrepare(Config[] configs) {
		if(configs == null || configs.length == 0)
			return null;

		Config[] cnf = Arrays.stream(configs)
				.filter(c -> c != null && !c.isDisabled())
				.peek(c -> c.init(this))
				.toArray(Config[]::new);

		Map<String, List<Config>> map = Arrays.stream(cnf).filter(c -> c.getName() != null).collect(Collectors.groupingBy(Config::getName));

		map.values().removeIf(l -> l.size() < 2);
		if(!map.isEmpty()) {
			Logger l = LoggerFactory.getLogger(Config.class);
			StringBuilder sb = new StringBuilder();
			sb.append("-------- conflicting config.name --------\n");
			map.forEach((name, cnfs) -> {
				sb.append(name).append('\n');
				cnfs.forEach(c -> sb.append("    ").append(c.getSource()).append('\n'));
			});
			l.error(sb.toString());
			System.exit(0);
		}
		return cnf;
	}
	public Config[] getBackups() {
		if(_backups != null)
			return _backups;

		return _backups = filterAndPrepare(backups);
	}
	@Override
	public IFilter getSourceFilter() {
		return excludes;
	}
	@Override
	public IFilter getTargetFilter() {
		return targetExcludes;
	}
	@Override
	protected RootConfig getRoot() {
		return this;
	}

	public Path getBackupRoot() {
		if(_backupRoot == null) {
			String s = variables.get("backupRoot");
			s = s != null ? s : resolve(backupRoot);
			_backupRoot = pathResolve(s);
		}
		return _backupRoot;
	}
	public String getBackupRootRaw() {
		return backupRoot;
	}
	private LazyAndWeak<StringBuffer> buffer = new LazyAndWeak<>(StringBuffer::new);
	private LazyAndWeak<Pattern> pattern = new LazyAndWeak<>(() -> Pattern.compile("%(.+?)%"));
	
	public String resolve(String variable) {
		if(!StringUtils.contains(variable, '%'))
			return variable;

		StringBuffer sb = this.buffer.get();
		sb.setLength(0);
		Matcher m = this.pattern.get().matcher(variable);
		
		while(m.find()) {
			String s = getVariable(m.group(1));
			if(s == null)
				return null;
			m.appendReplacement(sb, s);
		}
		
		return sb.toString();
	}
	
	private DetectDrive detectDrive;
	private String getVariable(String variable) {
		if(variable.equals("DETECTED_DRIVE")) {
			detectDrive = detectDrive != null ? detectDrive : new DetectDrive();
			variables.put("DETECTED_DRIVE", Optional.ofNullable(detectDrive.getDrive()).map(Object::toString).orElse(null));
		}
		
		String result = variables.get(variable);
		
		if(result == null) {
			if(variable.equals("backupRoot")) {
				String s = getBackupRoot().toString();
				variables.put("backupRoot", s);
				return s;
			}
				
			logger().error("value not found for variable: "+variable);
		}
		
		if(StringUtils.contains(result, '%')) {
			String s = resolve(result);
			variables.put(variable, s);
			return s;
		}
		return result;
	}
	public String getID() {
		if(!backupRootExists())
			return "0";
		
		if(detectDrive == null)
			return String.valueOf(getBackupRoot().hashCode());
		else
			return detectDrive.getId();
	}

	public boolean backupRootExists() {
		return getBackupRoot() != null;
	}
}

