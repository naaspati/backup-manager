package sam.backup.manager.config.json.impl;

import java.util.List;

import sam.backup.manager.config.api.Config;
import sam.backup.manager.config.api.ConfigManager;
import sam.nopkg.Junk;

public class JsonManager implements ConfigManager {

	@Override
	public List<Config> getBackups() {
		// TODO Auto-generated method stub
		return Junk.notYetImplemented();
	}

	@Override
	public List<Config> getLists() {
		// TODO Auto-generated method stub
		return Junk.notYetImplemented();
	}

}
