import java.io.File;

import org.slf4j.LoggerFactory;

import javafx.application.Application;
import sam.backup.manager.App;
import sam.fileutils.FileOpener;

public class Main  {
	public static void main(String[] args) {
		if(args.length == 1 && args[0].equals("open")) {
			FileOpener.getInstance().openFileNoError(new File("."));
			System.exit(0);
		}
		if(args.length == 1 && args[0].equals("-v")) {
			System.out.println("1.04");
			System.exit(0);
		}
		Thread.setDefaultUncaughtExceptionHandler((thread, exception) -> LoggerFactory.getLogger(Main.class).error("thread: {}", thread.getName(), exception));
		Application.launch(App.class, args);
	}
}
