package sam.backup.manager.config.api;

import sam.nopkg.Junk;

public final class ConfigManagerFactory {
	public static ConfigManager defaultInstance() {
		//FIXME
		return Junk.notYetImplemented();
	}
	
	
}