package sam.backup.manager.file;

import java.nio.file.Path;
import java.util.Collection;

import sam.backup.manager.extra.Writable;
import sam.nopkg.Junk;

public class PathListToFileTree implements Writable {
	
	public PathListToFileTree(Collection<Path> path) {
		Junk.notYetImplemented();
		// TODO Auto-generated constructor stub
	}

	@Override
	public void write(Appendable sink) {
		// TODO Auto-generated method stub
		
	}

}
