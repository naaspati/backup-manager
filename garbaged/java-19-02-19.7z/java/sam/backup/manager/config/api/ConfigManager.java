package sam.backup.manager.config.api;

import java.util.List;

public interface ConfigManager {
	 List<Config> getBackups();
	 List<Config> getLists();
} 