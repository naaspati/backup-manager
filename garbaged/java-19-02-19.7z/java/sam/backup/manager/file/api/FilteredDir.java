package sam.backup.manager.file.api;

public interface FilteredDir extends Dir {
	FilteredDir getParent() ;

}
