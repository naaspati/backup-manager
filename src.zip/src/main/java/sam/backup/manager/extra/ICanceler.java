package sam.backup.manager.extra;

public interface ICanceler {
	public boolean isCancelled();
}
