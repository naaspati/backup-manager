package sam.backup.manager.view;

public interface IUpdatable {
	public void update();
}
