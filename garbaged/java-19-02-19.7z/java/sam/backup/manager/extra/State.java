package sam.backup.manager.extra;

public enum State {
	UPLOADING,
	COMPLETED,
	CANCELLED,
	WALKING,
	QUEUED,
	FAILED
}
