package sam.backup.manager.config.view;

import static javafx.application.Platform.runLater;
import static sam.fx.helpers.FxClassHelper.addClass;
import static sam.fx.helpers.FxClassHelper.setClass;
import static sam.fx.helpers.FxText.text;

import java.io.IOException;
import java.nio.file.FileStore;
import java.nio.file.Files;

import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import sam.backup.manager.config.RootConfig;
import sam.backup.manager.extra.Utils;
import sam.fx.helpers.FxText;
import sam.myutils.MyUtilsException;

public class AboutDriveView extends VBox  {
	private Text sizeText;
	private final RootConfig root;

	public AboutDriveView(RootConfig root) {
		setClass(this, "root-view");
		this.root = root;
		
		if(root.getBackupRoot() == null) {
			sizeText = null;
			Text t =FxText.ofString("BackupRoot Not Found");
			Text t0 = text(root.getBackupRootRaw(), "full-path-text");
			
			Text t2 = text("Drive must contain file ", "drive-warning-text-1");
			Text t3 = text(".iambackup", "drive-warning-text-2");
			Text t4 = text(" (hidden or visible)", "drive-warning-text-1");

			addClass("size-text", t2,t3, t4);

			getChildren().setAll(new Text(""), t, t0, new TextFlow(t2,t3, t4));
		}
		else {
			sizeText  = text("", "size-text");
			Text t = text(String.valueOf(root.getBackupRoot()), "full-path-text"); 
			getChildren().addAll(new Text("Backup To"), t, sizeText);

			runLater(this::refreshSize);
		}
	}

	public void refreshSize() {
		if(root.getBackupRoot() == null)
			return;
		try {
			FileStore fs = Files.getFileStore(root.getBackupRoot().getRoot());
			sizeText.setText("Total Space: "+Utils.bytesToString(fs.getTotalSpace())+
					" | Free Space: "+Utils.bytesToString(fs.getUnallocatedSpace())
					);
		} catch (IOException e) {
			sizeText.setText(MyUtilsException.exceptionToString(e));
		}
	}
}
