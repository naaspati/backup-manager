package sam.backup.manager.extra;

public interface IStopStart {
	public void stop();
	public void start();
}
