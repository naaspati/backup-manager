package sam.backup.manager.config.json.impl;

interface Settable {
	void set(String key, Object value) ;
}
