package sam.backup.manager.extra;

public interface VariablesKeys {
	String DETECTED_DRIVE = "DETECTED_DRIVE",
			DETECTED_DRIVE_ID = "DETECTED_DRIVE_ID";
}
