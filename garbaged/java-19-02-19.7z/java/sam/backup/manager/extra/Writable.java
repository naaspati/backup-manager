package sam.backup.manager.extra;

public interface Writable {
	void write(Appendable sink);
}
